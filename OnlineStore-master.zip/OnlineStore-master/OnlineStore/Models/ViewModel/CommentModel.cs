﻿namespace OnlineStore.Models.ViewModel
{
    public class CommentModel
    {
        public int UserId { get; set; }
        public int ProductId { get; set; }
        public string Text { get; set; }
    }
}
