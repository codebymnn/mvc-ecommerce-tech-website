﻿using System; 
using System.Collections.Generic;
using OnlineStore.Models.Database;
using System.Linq;
namespace OnlineStore.Models.ViewModel
{
    public class ProductModel : Product
    {
        
    }
}
