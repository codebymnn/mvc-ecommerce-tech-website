﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace OnlineStore.Models.ViewModel
{
    public class SuccesViewModel
    {
        public decimal TotalPrice { get; set; }
    }
}
