# OnlineStore
## Description
Online store is a ecommerce shop thet everybody can download and use.
## Installing and using
All needed preinstalled software:
* IIS Express
* Microsoft SQL Server
* Microsoft Visual Studio 2019

Used frameworks and libraries:
* NET Core 3.0
* ASP NET Core 3.0
* Entity Framework Core 3.0

Installation instruction:
* Clone this repository
* Open the solution in Microsoft Visual Studio 
* Update database with command `update-database`
* Run the project
